/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package contactos;
import java.sql.*;
/**
 *
 * @author WILLIAM A TORRES L
 */
public class Persona {
  conectate conn;
  
  public Persona (){
     conn = new conectate();
  } 
  public void nuevaPersona(String nombre, String apellidoPaterno, String apellidoMaterno, String correo) {
        try {            
            PreparedStatement pstm = conn.getConnection().prepareStatement("insert into "
                    + "persona(Nombre, appPaterno, appMaterno, mail) "
                    + " values(?,?,?,?)");
            pstm.setString(1, nombre);
            pstm.setString(2, apellidoPaterno);
            pstm.setString(3, apellidoMaterno);
            pstm.setString(4, correo);
            pstm.execute();
            pstm.close();

        } catch (Exception e) {
            System.out.println(e);
        }
    }
  
  public Object[][] getDatos() {
        int registros = 0;
        try {
            PreparedStatement pstm = conn.getConnection().prepareStatement("SELECT count(1) as total FROM persona ");
            ResultSet res = pstm.executeQuery();
            res.next();
            registros = res.getInt("total");
            res.close();
        } catch (SQLException e) {
            System.out.println(e);
        }
        Object[][] data = new String[registros][5];
        try {
            PreparedStatement pstm = conn.getConnection().prepareStatement("SELECT "
                    + " id, Nombre, appPaterno, appMaterno, mail "
                    + " FROM persona"
                    + " ORDER BY id DESC");
            ResultSet res = pstm.executeQuery();
        int i= 0;
        while (res.next()) {
                String estCodigo = res.getString("id");
                String estNombre = res.getString("nombre");
                String estpaterno = res.getString("appPaterno");
                String estmaterno = res.getString("appMaterno");
                String estmail = res.getString("mail");
                data[i][0] = estCodigo;
        data[i][1] = estNombre;
                data[i][2] = estpaterno;
                data[i][3] = estmaterno;
                data[i][4] = estmail;
                i++;
            }

            res.close();
}       catch (SQLException e) {
            System.out.println(e);
        }

        return data;

    }
    public void deletePersona(String cod) {
        try {
            PreparedStatement pstm = conn.getConnection().prepareStatement("delete from persona where id = ?");
            pstm.setString(1, cod);
            pstm.execute();
            pstm.close();
        } catch (SQLException e) {
            System.out.println(e);
        }
    }
    public void updatePersona(String id, String name, String paterno, String materno, String mail){
       try {            
            PreparedStatement pstm = conn.getConnection().prepareStatement("update persona " +
            "set Nombre = ? ," +
            "appPaterno = ? ," +
            "appMaterno = ? ," +                    
            "mail = ? " +                    
            "where id = ? ");            
            pstm.setString(1, name);
            pstm.setString(2, paterno);
            pstm.setString(3, materno);
            pstm.setString(4, mail);
            pstm.setString(5, String.valueOf(id));
            pstm.execute();
            pstm.close();            
         }catch(SQLException e){
         System.out.println(e);
      }
   }

    void updatePersona(String string, String marcela) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
  

